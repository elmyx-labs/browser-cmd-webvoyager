#!/usr/bin/env python3
"""Stop hook: in a session that browsed with browser-cmd, an attempt to finish
becomes one validation pass only when the validation record says it is due:
.browser-cmd/CHECK.md is missing or has a fail/unknown row, or the answer file
named by BROWSER_CMD_ANSWER_FILE (when set) is missing. Otherwise the session
stops with the answer it has.

A session browsed when its transcript shows a browser-cmd command or, for a
session run without a transcript, when browser-cmd left its mark in the working
directory."""
import json
import os
import re
import sys

REASON = (
    'Validate before finishing. {why} Reread the request and .browser-cmd/CHECK.md (create it if it is '
    'missing) together with your answer. If a row is fail or unknown, if a step the request asks for '
    'was not carried out, or if the answer notes an unmet or unverified condition, and a '
    'non-committing browser route could settle it, take that route now and update CHECK.md, the '
    'answer and any file the request asked for. If every row passes, or nothing available can '
    'settle what remains, finish with the answer as it is.'
)
OPEN_ROW = re.compile(r'^(fail|unknown)\b')


def browsed(transcript):
    """Whether any shell command in the session ran browser-cmd."""
    try:
        lines = open(transcript, encoding='utf-8')
    except OSError:
        return False
    with lines:
        for line in lines:
            if 'browser-cmd' not in line:
                continue
            try:
                content = json.loads(line).get('message', {}).get('content', [])
            except ValueError:
                continue
            for part in content if isinstance(content, list) else []:
                if part.get('type') == 'tool_use' and 'browser-cmd' in str(part.get('input', {}).get('command', '')):
                    return True
    return False


def open_rows(check):
    """Table rows of CHECK.md whose verdict (last cell) is fail or unknown."""
    rows = []
    for line in check.splitlines():
        cells = [cell.strip(' *`_').lower() for cell in line.strip().strip('|').split('|')]
        if line.lstrip().startswith('|') and OPEN_ROW.match(cells[-1]):
            rows.append(line.strip())
    return rows


def due(cwd, answer_file):
    """Why validation is still due, or None when the record says it is done."""
    try:
        with open(os.path.join(cwd, '.browser-cmd', 'CHECK.md'), encoding='utf-8') as check:
            rows = open_rows(check.read())
    except OSError:
        return '.browser-cmd/CHECK.md is missing.'
    if rows:
        return f'CHECK.md has {len(rows)} fail/unknown row(s).'
    if answer_file and not os.path.exists(os.path.join(cwd, answer_file)):
        return f'{answer_file} is missing.'
    return None


def decide(event, answer_file):
    """The hook's output for a Stop event, or None to let the session stop."""
    if event.get('stop_hook_active'):
        return None
    cwd = event.get('cwd', '')
    if not (os.path.exists(os.path.join(cwd, '.browser-cmd', 'used')) or browsed(event.get('transcript_path', ''))):
        return None
    why = due(cwd, answer_file)
    return {'decision': 'block', 'reason': REASON.format(why=why)} if why else None


if __name__ == '__main__':
    verdict = decide(json.load(sys.stdin), os.environ.get('BROWSER_CMD_ANSWER_FILE'))
    if verdict:
        print(json.dumps(verdict))
